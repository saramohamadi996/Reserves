<?php

namespace Gym\Category\Http\Api\Controllers;

use Gym\User\Http\Controllers\Controller;

class CategoryController extends Controller
{

}
