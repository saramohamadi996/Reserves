<head>
    <meta charset="utf-8"/>
    <title>رزرو ورزش سافت | پنل ادمین</title>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <link href="{{asset('assets/css/vendor.min.css')}}" rel="stylesheet"/>
    <link href="{{asset('assets/css/app.min.css')}}" rel="stylesheet"/>
    <link href="{{asset('assets/plugins/datatables.net-bs5/css/dataTables.bootstrap5.min.css')}}" rel="stylesheet"/>
    <link href="{{asset('assets/plugins/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css')}}"
          rel="stylesheet"/>
    <link href="{{asset('assets/plugins/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')}}"
          rel="stylesheet"/>
    <link href="{{asset('assets/plugins/bootstrap-table/dist/bootstrap-table.min.css')}}" rel="stylesheet"/>
    <link href="{{asset('assets/plugins/jvectormap-next/jquery-jvectormap.css')}}" rel="stylesheet" />
    <link rel="stylesheet" href="{{asset('/assets/css/persianDatepicker-default.css')}}">
    <link href="{{asset('/assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css')}}"
          rel="stylesheet"/>
    <link href="{{asset('assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')}}"
          rel="stylesheet"/>
    <link href="{{asset('/assets/css/select2.min.css')}}" rel="stylesheet" />
    <link rel="stylesheet" href="{{asset('assets/material-rtl-time-picker/mdtimepicker.css')}}">
    @yield('css')
</head>
