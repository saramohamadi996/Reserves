{{--<div class="app-theme-panel">--}}
{{--    <div class="app-theme-panel-container">--}}
{{--        <a href="javascript:;" data-toggle="theme-panel-expand" class="app-theme-toggle-btn"><i--}}
{{--                class="bi bi-sliders"></i></a>--}}
{{--        <div class="app-theme-panel-content">--}}
{{--            <div class="small fw-bold text-white mb-1">رنگ قالب</div>--}}
{{--            <div class="card mb-3">--}}

{{--                <div class="card-body p-2">--}}
{{--                    <div class="app-theme-list">--}}
{{--                        <div class="app-theme-list-item"><a href="javascript:;"--}}
{{--                                                            class="app-theme-list-link bg-pink" data-theme-class="theme-pink"--}}
{{--                                                            data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                            data-bs-container="body" data-bs-title="صورتی">&nbsp;</a></div>--}}
{{--                        <div class="app-theme-list-item"><a href="javascript:;"--}}
{{--                                                            class="app-theme-list-link bg-red" data-theme-class="theme-red"--}}
{{--                                                            data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                            data-bs-container="body" data-bs-title="قرمز">&nbsp;</a></div>--}}
{{--                        <div class="app-theme-list-item"><a href="javascript:;"--}}
{{--                                                            class="app-theme-list-link bg-warning" data-theme-class="theme-warning"--}}
{{--                                                            data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                            data-bs-container="body" data-bs-title="نارنجی">&nbsp;</a></div>--}}
{{--                        <div class="app-theme-list-item"><a href="javascript:;"--}}
{{--                                                            class="app-theme-list-link bg-yellow" data-theme-class="theme-yellow"--}}
{{--                                                            data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                            data-bs-container="body" data-bs-title="زرد">&nbsp;</a></div>--}}
{{--                        <div class="app-theme-list-item"><a href="javascript:;"--}}
{{--                                                            class="app-theme-list-link bg-lime" data-theme-class="theme-lime"--}}
{{--                                                            data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                            data-bs-container="body" data-bs-title="لیمویی">&nbsp;</a></div>--}}
{{--                        <div class="app-theme-list-item"><a href="javascript:;"--}}
{{--                                                            class="app-theme-list-link bg-green" data-theme-class="theme-green"--}}
{{--                                                            data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                            data-bs-container="body" data-bs-title="سبز">&nbsp;</a></div>--}}
{{--                        <div class="app-theme-list-item active"><a href="javascript:;"--}}
{{--                                                                   class="app-theme-list-link bg-teal" data-theme-class=""--}}
{{--                                                                   data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                                   data-bs-container="body" data-bs-title="پیشفرض">&nbsp;</a></div>--}}
{{--                        <div class="app-theme-list-item"><a href="javascript:;"--}}
{{--                                                            class="app-theme-list-link bg-info" data-theme-class="theme-info"--}}
{{--                                                            data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                            data-bs-container="body" data-bs-title="سبزآبی">&nbsp;</a></div>--}}
{{--                        <div class="app-theme-list-item"><a href="javascript:;"--}}
{{--                                                            class="app-theme-list-link bg-primary" data-theme-class="theme-primary"--}}
{{--                                                            data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                            data-bs-container="body" data-bs-title="آبی">&nbsp;</a></div>--}}
{{--                        <div class="app-theme-list-item"><a href="javascript:;"--}}
{{--                                                            class="app-theme-list-link bg-purple" data-theme-class="theme-purple"--}}
{{--                                                            data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                            data-bs-container="body" data-bs-title="بنفش">&nbsp;</a></div>--}}
{{--                        <div class="app-theme-list-item"><a href="javascript:;"--}}
{{--                                                            class="app-theme-list-link bg-indigo" data-theme-class="theme-indigo"--}}
{{--                                                            data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                            data-bs-container="body" data-bs-title="یاسی">&nbsp;</a></div>--}}
{{--                        <div class="app-theme-list-item"><a href="javascript:;"--}}
{{--                                                            class="app-theme-list-link bg-gray-100" data-theme-class="theme-gray-200"--}}
{{--                                                            data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover"--}}
{{--                                                            data-bs-container="body" data-bs-title="خاکستری">&nbsp;</a></div>--}}
{{--                    </div>--}}
{{--                </div>--}}

{{--                <div class="card-arrow">--}}
{{--                    <div class="card-arrow-top-left"></div>--}}
{{--                    <div class="card-arrow-top-right"></div>--}}
{{--                    <div class="card-arrow-bottom-left"></div>--}}
{{--                    <div class="card-arrow-bottom-right"></div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--            <div class="small fw-bold text-white mb-1">کاور تم</div>--}}
{{--            <div class="card">--}}
{{--                <div class="card-body p-2">--}}
{{--                    <div class="app-theme-cover">--}}
{{--                        <div class="app-theme-cover-item active">--}}
{{--                            <a href="javascript:;" class="app-theme-cover-link"--}}
{{--                               style="background-image: url(assets/img/cover/cover-thumb-1.jpg);"--}}
{{--                               data-theme-cover-class="" data-toggle="theme-cover-selector"--}}
{{--                               data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body"--}}
{{--                               data-bs-title="پیشفرض">&nbsp;</a>--}}
{{--                        </div>--}}
{{--                        <div class="app-theme-cover-item">--}}
{{--                            <a href="javascript:;" class="app-theme-cover-link"--}}
{{--                               style="background-image: url(assets/img/cover/cover-thum1b-2.jpg);"--}}
{{--                               data-theme-cover-class="bg-cover-2" data-toggle="theme-cover-selector"--}}
{{--                               data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body"--}}
{{--                               data-bs-title="کاور 2">&nbsp;</a>--}}
{{--                        </div>--}}
{{--                        <div class="app-theme-cover-item">--}}
{{--                            <a href="javascript:;" class="app-theme-cover-link"--}}
{{--                               style="background-image: url(assets/img/cover/cover-thum1b-3.jpg);"--}}
{{--                               data-theme-cover-class="bg-cover-3" data-toggle="theme-cover-selector"--}}
{{--                               data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body"--}}
{{--                               data-bs-title="کاور 3">&nbsp;</a>--}}
{{--                        </div>--}}
{{--                        <div class="app-theme-cover-item">--}}
{{--                            <a href="javascript:;" class="app-theme-cover-link"--}}
{{--                               style="background-image: url(assets/img/cover/cover-thu1mb-4.jpg);"--}}
{{--                               data-theme-cover-class="bg-cover-4" data-toggle="theme-cover-selector"--}}
{{--                               data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body"--}}
{{--                               data-bs-title="کاور 4">&nbsp;</a>--}}
{{--                        </div>--}}
{{--                        <div class="app-theme-cover-item">--}}
{{--                            <a href="javascript:;" class="app-theme-cover-link"--}}
{{--                               style="background-image: url(assets/img/cover/cover-th1umb-5.jpg);"--}}
{{--                               data-theme-cover-class="bg-cover-5" data-toggle="theme-cover-selector"--}}
{{--                               data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body"--}}
{{--                               data-bs-title="کاور 5">&nbsp;</a>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <div class="card-arrow">--}}
{{--                    <div class="card-arrow-top-left"></div>--}}
{{--                    <div class="card-arrow-top-right"></div>--}}
{{--                    <div class="card-arrow-bottom-left"></div>--}}
{{--                    <div class="card-arrow-bottom-right"></div>--}}
{{--                </div>--}}

{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}
{{--</div>--}}
