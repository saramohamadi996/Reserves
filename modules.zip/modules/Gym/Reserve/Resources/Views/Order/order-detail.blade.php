
<div class="pos pos-vertical card" id="pos">
    <div class="h-100 d-flex flex-column p-0">
        <div class="h-100 d-flex justify-content-center text-center">
        <div id="order-table">
            @include('Reserve::Order.order-table')
        </div>
    </div>
    </div>
    <div class="card-arrow">
        <div class="card-arrow-top-left"></div>
        <div class="card-arrow-top-right"></div>
        <div class="card-arrow-bottom-left"></div>
        <div class="card-arrow-bottom-right"></div>
    </div>
</div>
