
<div class="tab-pane fade h-100" id="orderHistoryTab">
    <div class="h-100 d-flex">
        <div id="order-table">
            @include('Reserve::Order.order-table')
        </div>
    </div>
</div>
