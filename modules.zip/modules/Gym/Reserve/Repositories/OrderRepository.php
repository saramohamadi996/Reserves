<?php

namespace Gym\Reserve\Repositories;

use Gym\Reserve\Repositories\Interfaces\orderRepositoryInterface;

class OrderRepository extends orderRepositoryInterface
{

}
