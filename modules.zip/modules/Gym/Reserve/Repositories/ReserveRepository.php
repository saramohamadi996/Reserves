<?php

namespace Gym\Reserve\Repositories;

use Gym\Reserve\Repositories\Interfaces\ReserveRepositoryInterfaces;

class ReserveRepository implements ReserveRepositoryInterfaces
{

}
