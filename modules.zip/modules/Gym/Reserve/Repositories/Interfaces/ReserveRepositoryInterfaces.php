<?php

namespace Gym\Reserve\Repositories\Interfaces;

interface ReserveRepositoryInterfaces
{

}
