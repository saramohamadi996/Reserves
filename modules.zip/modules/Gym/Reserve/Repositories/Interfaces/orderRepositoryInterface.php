<?php

namespace Gym\Reserve\Repositories\Interfaces;

class orderRepositoryInterface
{

}
