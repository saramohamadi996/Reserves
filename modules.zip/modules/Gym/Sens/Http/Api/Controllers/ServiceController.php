<?php

namespace Gym\Service\Http\Api\Controllers;

use Gym\User\Http\Controllers\Controller;

class ServiceController extends Controller
{

}
