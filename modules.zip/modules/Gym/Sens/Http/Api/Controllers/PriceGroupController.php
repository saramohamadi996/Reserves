<?php

namespace Gym\Service\Http\Api\Controllers;

use Gym\User\Http\Controllers\Controller;

class PriceGroupController extends Controller
{

}
